package cursos.cursos_online.role.service;

import cursos.cursos_online.role.domain.Role;
import cursos.cursos_online.role.model.RoleDTO;
import cursos.cursos_online.role.repos.RoleRepository;
import cursos.cursos_online.usuario.domain.Usuario;
import cursos.cursos_online.usuario.repos.UsuarioRepository;
import cursos.cursos_online.util.NotFoundException;
import cursos.cursos_online.util.ReferencedWarning;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service class for managing Role entities.
 */
@Service
public class RoleService {

    private final RoleRepository roleRepository;
    private final UsuarioRepository usuarioRepository;

    public RoleService(final RoleRepository roleRepository,
                       final UsuarioRepository usuarioRepository) {
        this.roleRepository = roleRepository;
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Get all roles.
     *
     * @return the list of roles
     */
    public List<RoleDTO> findAll() {
        final List<Role> roles = roleRepository.findAll(Sort.by("id"));
        return roles.stream()
                .map(role -> mapToDTO(role, new RoleDTO()))
                .toList();
    }

    /**
     * Get a role by id.
     *
     * @param id the id of the role to retrieve
     * @return the role DTO
     * @throws NotFoundException if the role is not found
     */
    public RoleDTO get(final Integer id) {
        return roleRepository.findById(id)
                .map(role -> mapToDTO(role, new RoleDTO()))
                .orElseThrow(NotFoundException::new);
    }

    /**
     * Create a new role.
     *
     * @param roleDTO the roleDTO to create
     * @return the id of the newly created role
     */
    public Integer create(final RoleDTO roleDTO) {
        final Role role = new Role();
        mapToEntity(roleDTO, role);
        return roleRepository.save(role).getId();
    }

    /**
     * Update an existing role.
     *
     * @param id      the id of the role to update
     * @param roleDTO the roleDTO to update
     * @throws NotFoundException if the role is not found
     */
    public void update(final Integer id, final RoleDTO roleDTO) {
        final Role role = roleRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(roleDTO, role);
        roleRepository.save(role);
    }

    /**
     * Delete a role by id.
     *
     * @param id the id of the role to delete
     */
    public void delete(final Integer id) {
        roleRepository.deleteById(id);
    }

    private RoleDTO mapToDTO(final Role role, final RoleDTO roleDTO) {
        roleDTO.setId(role.getId());
        roleDTO.setRol(role.getRol());
        return roleDTO;
    }

    private Role mapToEntity(final RoleDTO roleDTO, final Role role) {
        role.setRol(roleDTO.getRol());
        return role;
    }

    /**
     * Get a warning if the role is referenced by other entities.
     *
     * @param id the id of the role to check
     * @return the warning if the role is referenced by other entities, null otherwise
     */
    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Role role = roleRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Usuario rolUsuario = usuarioRepository.findFirstByRol(role);
        if (rolUsuario != null) {
            referencedWarning.setKey("role.usuario.rol.referenced");
            referencedWarning.addParam(rolUsuario.getId());
            return referencedWarning;
        }
        return null;
    }
}
