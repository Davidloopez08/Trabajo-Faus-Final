package cursos.cursos_online.curso.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CursoDTO {

    // Identificador del curso
    private Integer id;

    // Nombre del curso (requerido, máximo 100 caracteres)
    @NotNull
    @Size(max = 100)
    private String nombre;

    // Descripción del curso
    private String descripcion;

    // Fecha de inicio del curso
    private LocalDate fechaInicio;

    // Fecha de finalización del curso
    private LocalDate fechaFin;

    // Identificador de la categoría del curso
    private Integer categoria;
}
