package cursos.cursos_online.inscripcione.rest;

import cursos.cursos_online.inscripcione.model.InscripcioneDTO;
import cursos.cursos_online.inscripcione.service.InscripcioneService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for managing inscriptions.
 */
@RestController
@RequestMapping(value = "/api/inscripciones", produces = MediaType.APPLICATION_JSON_VALUE)
public class InscripcioneResource {

    private final InscripcioneService inscripcioneService;

    public InscripcioneResource(final InscripcioneService inscripcioneService) {
        this.inscripcioneService = inscripcioneService;
    }

    /**
     * Retrieves all inscriptions.
     *
     * @return ResponseEntity containing a list of InscripcioneDTOs and HttpStatus.OK.
     */
    @GetMapping
    public ResponseEntity<List<InscripcioneDTO>> getAllInscripciones() {
        return ResponseEntity.ok(inscripcioneService.findAll());
    }

    /**
     * Retrieves an inscription by its ID.
     *
     * @param id The ID of the inscription to retrieve.
     * @return ResponseEntity containing the InscripcioneDTO and HttpStatus.OK if found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<InscripcioneDTO> getInscripcione(
            @PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(inscripcioneService.get(id));
    }

    /**
     * Creates a new inscription.
     *
     * @param inscripcioneDTO The InscripcioneDTO containing the data of the new inscription.
     * @return ResponseEntity containing the ID of the created inscription and HttpStatus.CREATED.
     */
    @PostMapping
    public ResponseEntity<Integer> createInscripcione(
            @RequestBody @Valid final InscripcioneDTO inscripcioneDTO) {
        final Integer createdId = inscripcioneService.create(inscripcioneDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    /**
     * Updates an existing inscription.
     *
     * @param id The ID of the inscription to update.
     * @param inscripcioneDTO The InscripcioneDTO containing the updated data.
     * @return ResponseEntity containing the ID of the updated inscription and HttpStatus.OK.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateInscripcione(@PathVariable(name = "id") final Integer id,
                                                      @RequestBody @Valid final InscripcioneDTO inscripcioneDTO) {
        inscripcioneService.update(id, inscripcioneDTO);
        return ResponseEntity.ok(id);
    }

    /**
     * Deletes an inscription by its ID.
     *
     * @param id The ID of the inscription to delete.
     * @return ResponseEntity with no content and HttpStatus.NO_CONTENT.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInscripcione(@PathVariable(name = "id") final Integer id) {
        inscripcioneService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
