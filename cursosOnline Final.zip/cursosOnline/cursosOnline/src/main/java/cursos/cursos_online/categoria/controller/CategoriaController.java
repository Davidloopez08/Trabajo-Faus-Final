package cursos.cursos_online.categoria.controller;

import cursos.cursos_online.categoria.model.CategoriaDTO;
import cursos.cursos_online.categoria.service.CategoriaService;
import cursos.cursos_online.util.ReferencedWarning;
import cursos.cursos_online.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Controlador para manejar las operaciones relacionadas con las categorías.
 */
@Controller
@RequestMapping("/categorias")
public class CategoriaController {

    private final CategoriaService categoriaService;

    /**
     * Constructor de la clase.
     *
     * @param categoriaService Servicio de categoría a inyectar en el controlador.
     */
    public CategoriaController(final CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    /**
     * Método que muestra la lista de categorías.
     *
     * @param model Modelo para agregar atributos para la vista.
     * @return La vista "categoria/list" que muestra la lista de categorías.
     */
    @GetMapping
    public String list(final Model model) {
        model.addAttribute("categorias", categoriaService.findAll());
        return "categoria/list";
    }

    /**
     * Método que muestra el formulario para agregar una nueva categoría.
     *
     * @param categoriaDTO Objeto DTO para almacenar los datos de la nueva categoría.
     * @return La vista "categoria/add" que muestra el formulario de agregar categoría.
     */
    @GetMapping("/add")
    public String add(@ModelAttribute("categoria") final CategoriaDTO categoriaDTO) {
        return "categoria/add";
    }

    /**
     * Método que procesa la solicitud de agregar una nueva categoría.
     *
     * @param categoriaDTO         Objeto DTO que contiene los datos de la categoría a agregar.
     * @param bindingResult        Resultado del proceso de validación de datos.
     * @param redirectAttributes  Atributos de redirección para enviar mensajes de éxito o error.
     * @return Redirige a la lista de categorías si la operación fue exitosa; de lo contrario, vuelve al formulario de agregar categoría.
     */
    @PostMapping("/add")
    public String add(@ModelAttribute("categoria") @Valid final CategoriaDTO categoriaDTO,
                      final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "categoria/add";
        }
        categoriaService.create(categoriaDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("categoria.create.success"));
        return "redirect:/categorias";
    }

    /**
     * Método que muestra el formulario para editar una categoría existente.
     *
     * @param id     ID de la categoría a editar.
     * @param model  Modelo para agregar atributos para la vista.
     * @return La vista "categoria/edit" que muestra el formulario de edición de categoría.
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id, final Model model) {
        model.addAttribute("categoria", categoriaService.get(id));
        return "categoria/edit";
    }

    /**
     * Método que procesa la solicitud de editar una categoría existente.
     *
     * @param id                    ID de la categoría a editar.
     * @param categoriaDTO          Objeto DTO que contiene los datos actualizados de la categoría.
     * @param bindingResult         Resultado del proceso de validación de datos.
     * @param redirectAttributes   Atributos de redirección para enviar mensajes de éxito o error.
     * @return Redirige a la lista de categorías si la operación fue exitosa; de lo contrario, vuelve al formulario de edición de categoría.
     */
    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id,
                       @ModelAttribute("categoria") @Valid final CategoriaDTO categoriaDTO,
                       final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "categoria/edit";
        }
        categoriaService.update(id, categoriaDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("categoria.update.success"));
        return "redirect:/categorias";
    }

    /**
     * Método que procesa la solicitud de eliminar una categoría.
     *
     * @param id                    ID de la categoría a eliminar.
     * @param redirectAttributes   Atributos de redirección para enviar mensajes de éxito o error.
     * @return Redirige a la lista de categorías si la operación fue exitosa; de lo contrario, vuelve a la lista de categorías.
     */
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Integer id,
                         final RedirectAttributes redirectAttributes) {
        final ReferencedWarning referencedWarning = categoriaService.getReferencedWarning(id);
        if (referencedWarning != null) {
            redirectAttributes.addFlashAttribute(WebUtils.MSG_ERROR,
                    WebUtils.getMessage(referencedWarning.getKey(), referencedWarning.getParams().toArray()));
        } else {
            categoriaService.delete(id);
            redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("categoria.delete.success"));
        }
        return "redirect:/categorias";
    }

}
