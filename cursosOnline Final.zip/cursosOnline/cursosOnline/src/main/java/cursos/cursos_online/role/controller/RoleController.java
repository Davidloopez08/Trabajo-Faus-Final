package cursos.cursos_online.role.controller;

import cursos.cursos_online.role.model.RoleDTO;
import cursos.cursos_online.role.service.RoleService;
import cursos.cursos_online.util.ReferencedWarning;
import cursos.cursos_online.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Controller class for managing role-related operations.
 */
@Controller
@RequestMapping("/roles")
public class RoleController {

    private final RoleService roleService;

    /**
     * Constructor for RoleController.
     *
     * @param roleService The service for managing roles.
     */
    public RoleController(final RoleService roleService) {
        this.roleService = roleService;
    }

    /**
     * Displays the list of roles.
     *
     * @param model The model to be used in the view.
     * @return The view name for displaying the list of roles.
     */
    @GetMapping
    public String list(final Model model) {
        model.addAttribute("roles", roleService.findAll());
        return "role/list";
    }

    /**
     * Displays the form for adding a new role.
     *
     * @param roleDTO The DTO for the role to be added.
     * @return The view name for displaying the form for adding a new role.
     */
    @GetMapping("/add")
    public String add(@ModelAttribute("role") final RoleDTO roleDTO) {
        return "role/add";
    }

    /**
     * Handles the submission of the form for adding a new role.
     *
     * @param roleDTO            The DTO containing the data of the role to be added.
     * @param bindingResult      The result of the binding between the submitted data and the DTO.
     * @param redirectAttributes The attributes for the redirect request.
     * @return The redirect URL after adding the role.
     */
    @PostMapping("/add")
    public String add(@ModelAttribute("role") @Valid final RoleDTO roleDTO,
                      final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "role/add";
        }
        roleService.create(roleDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("role.create.success"));
        return "redirect:/roles";
    }

    /**
     * Displays the form for editing a role.
     *
     * @param id    The ID of the role to be edited.
     * @param model The model to be used in the view.
     * @return The view name for displaying the form for editing a role.
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id, final Model model) {
        model.addAttribute("role", roleService.get(id));
        return "role/edit";
    }

    /**
     * Handles the submission of the form for editing a role.
     *
     * @param id                  The ID of the role to be edited.
     * @param roleDTO             The DTO containing the updated data of the role.
     * @param bindingResult       The result of the binding between the submitted data and the DTO.
     * @param redirectAttributes  The attributes for the redirect request.
     * @return The redirect URL after editing the role.
     */
    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id,
                       @ModelAttribute("role") @Valid final RoleDTO roleDTO, final BindingResult bindingResult,
                       final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "role/edit";
        }
        roleService.update(id, roleDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("role.update.success"));
        return "redirect:/roles";
    }

    /**
     * Handles the deletion of a role.
     *
     * @param id                 The ID of the role to be deleted.
     * @param redirectAttributes The attributes for the redirect request.
     * @return The redirect URL after deleting the role.
     */
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Integer id,
                         final RedirectAttributes redirectAttributes) {
        final ReferencedWarning referencedWarning = roleService.getReferencedWarning(id);
        if (referencedWarning != null) {
            redirectAttributes.addFlashAttribute(WebUtils.MSG_ERROR,
                    WebUtils.getMessage(referencedWarning.getKey(), referencedWarning.getParams().toArray()));
        } else {
            roleService.delete(id);
            redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("role.delete.success"));
        }
        return "redirect:/roles";
    }

}
