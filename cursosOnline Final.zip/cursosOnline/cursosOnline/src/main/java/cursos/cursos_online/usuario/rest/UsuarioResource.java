package cursos.cursos_online.usuario.rest;

import cursos.cursos_online.usuario.model.UsuarioDTO;
import cursos.cursos_online.usuario.service.UsuarioService;
import cursos.cursos_online.util.ReferencedException;
import cursos.cursos_online.util.ReferencedWarning;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for handling Usuario resources.
 */
@RestController
@RequestMapping(value = "/api/usuarios", produces = MediaType.APPLICATION_JSON_VALUE)
public class UsuarioResource {

    private final UsuarioService usuarioService;

    public UsuarioResource(final UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    /**
     * Retrieves all usuarios.
     *
     * @return ResponseEntity containing a list of UsuarioDTOs and HTTP status 200 (OK).
     */
    @GetMapping
    public ResponseEntity<List<UsuarioDTO>> getAllUsuarios() {
        return ResponseEntity.ok(usuarioService.findAll());
    }

    /**
     * Retrieves a specific usuario by its ID.
     *
     * @param id The ID of the usuario to retrieve.
     * @return ResponseEntity containing the UsuarioDTO and HTTP status 200 (OK) if found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDTO> getUsuario(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(usuarioService.get(id));
    }

    /**
     * Creates a new usuario.
     *
     * @param usuarioDTO The usuarioDTO containing the information of the usuario to create.
     * @return ResponseEntity containing the ID of the created usuario and HTTP status 201 (Created).
     */
    @PostMapping
    public ResponseEntity<Integer> createUsuario(@RequestBody @Valid final UsuarioDTO usuarioDTO) {
        final Integer createdId = usuarioService.create(usuarioDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    /**
     * Updates an existing usuario.
     *
     * @param id         The ID of the usuario to update.
     * @param usuarioDTO The updated information of the usuario.
     * @return ResponseEntity containing the ID of the updated usuario and HTTP status 200 (OK).
     */
    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateUsuario(@PathVariable(name = "id") final Integer id,
                                                 @RequestBody @Valid final UsuarioDTO usuarioDTO) {
        usuarioService.update(id, usuarioDTO);
        return ResponseEntity.ok(id);
    }

    /**
     * Deletes a usuario by its ID.
     *
     * @param id The ID of the usuario to delete.
     * @return ResponseEntity with HTTP status 204 (No Content) if the usuario was deleted successfully.
     * @throws ReferencedException if the usuario is referenced by other entities.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUsuario(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = usuarioService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        usuarioService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
