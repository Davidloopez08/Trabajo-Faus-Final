package cursos.cursos_online.inscripcione.domain;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.usuario.domain.Usuario;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * Represents an inscription to a course in the system.
 */
@Entity
@Getter
@Setter
public class Inscripcione {

    /**
     * The unique identifier for the inscription.
     */
    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * The date and time when the inscription was made.
     */
    @Column
    private OffsetDateTime fechaInscripcion;

    /**
     * The user who made the inscription.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    public Usuario usuario;

    /**
     * The course to which the user is enrolled.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "curso_id")
    public Curso curso;

}
