package cursos.cursos_online.categoria.domain;

import cursos.cursos_online.curso.domain.Curso;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Clase que representa una categoría de cursos.
 */
@Entity
@Getter
@Setter
public class Categoria {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @OneToMany(mappedBy = "categoria")
    private Set<Curso> categoriaCursoes;

}
