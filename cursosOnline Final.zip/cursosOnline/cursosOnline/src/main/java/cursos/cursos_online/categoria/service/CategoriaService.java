package cursos.cursos_online.categoria.service;

import cursos.cursos_online.categoria.domain.Categoria;
import cursos.cursos_online.categoria.model.CategoriaDTO;
import cursos.cursos_online.categoria.repos.CategoriaRepository;
import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.curso.repos.CursoRepository;
import cursos.cursos_online.util.NotFoundException;
import cursos.cursos_online.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

/**
 * Servicio para realizar operaciones relacionadas con la entidad Categoria.
 */
@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;
    private final CursoRepository cursoRepository;

    public CategoriaService(final CategoriaRepository categoriaRepository,
                            final CursoRepository cursoRepository) {
        this.categoriaRepository = categoriaRepository;
        this.cursoRepository = cursoRepository;
    }

    /**
     * Obtiene todas las categorías.
     * @return Lista de objetos CategoriaDTO que representan todas las categorías.
     */
    public List<CategoriaDTO> findAll() {
        final List<Categoria> categorias = categoriaRepository.findAll(Sort.by("id"));
        return categorias.stream()
                .map(categoria -> mapToDTO(categoria, new CategoriaDTO()))
                .toList();
    }

    /**
     * Obtiene una categoría por su ID.
     * @param id El ID de la categoría a buscar.
     * @return El objeto CategoriaDTO que representa la categoría encontrada.
     * @throws NotFoundException si la categoría no se encuentra.
     */
    public CategoriaDTO get(final Integer id) {
        return categoriaRepository.findById(id)
                .map(categoria -> mapToDTO(categoria, new CategoriaDTO()))
                .orElseThrow(NotFoundException::new);
    }

    /**
     * Crea una nueva categoría.
     * @param categoriaDTO El DTO de la categoría a crear.
     * @return El ID de la categoría creada.
     */
    public Integer create(final CategoriaDTO categoriaDTO) {
        final Categoria categoria = new Categoria();
        mapToEntity(categoriaDTO, categoria);
        return categoriaRepository.save(categoria).getId();
    }

    /**
     * Actualiza una categoría existente.
     * @param id El ID de la categoría a actualizar.
     * @param categoriaDTO El DTO actualizado de la categoría.
     * @throws NotFoundException si la categoría a actualizar no se encuentra.
     */
    public void update(final Integer id, final CategoriaDTO categoriaDTO) {
        final Categoria categoria = categoriaRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(categoriaDTO, categoria);
        categoriaRepository.save(categoria);
    }

    /**
     * Elimina una categoría por su ID.
     * @param id El ID de la categoría a eliminar.
     */
    public void delete(final Integer id) {
        categoriaRepository.deleteById(id);
    }

    private CategoriaDTO mapToDTO(final Categoria categoria, final CategoriaDTO categoriaDTO) {
        categoriaDTO.setId(categoria.getId());
        categoriaDTO.setNombre(categoria.getNombre());
        return categoriaDTO;
    }

    private Categoria mapToEntity(final CategoriaDTO categoriaDTO, final Categoria categoria) {
        categoria.setNombre(categoriaDTO.getNombre());
        return categoria;
    }

    /**
     * Comprueba si una categoría está siendo referenciada por otros objetos.
     * @param id El ID de la categoría a comprobar.
     * @return Un objeto ReferencedWarning si la categoría está siendo referenciada por otros objetos, null si no.
     */
    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Categoria categoria = categoriaRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Curso categoriaCurso = cursoRepository.findFirstByCategoria(categoria);
        if (categoriaCurso != null) {
            referencedWarning.setKey("categoria.curso.categoria.referenced");
            referencedWarning.addParam(categoriaCurso.getId());
            return referencedWarning;
        }
        return null;
    }
}
