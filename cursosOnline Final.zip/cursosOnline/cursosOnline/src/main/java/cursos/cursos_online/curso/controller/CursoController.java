package cursos.cursos_online.curso.controller;

import cursos.cursos_online.categoria.domain.Categoria;
import cursos.cursos_online.categoria.repos.CategoriaRepository;
import cursos.cursos_online.curso.model.CursoDTO;
import cursos.cursos_online.curso.service.CursoService;
import cursos.cursos_online.util.CustomCollectors;
import cursos.cursos_online.util.ReferencedWarning;
import cursos.cursos_online.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/cursos")
public class CursoController {

    private final CursoService cursoService;
    private final CategoriaRepository categoriaRepository;

    /**
     * Constructor de CursoController.
     * @param cursoService Servicio para la gestión de cursos.
     * @param categoriaRepository Repositorio para la gestión de categorías.
     */
    public CursoController(final CursoService cursoService,
                           final CategoriaRepository categoriaRepository) {
        this.cursoService = cursoService;
        this.categoriaRepository = categoriaRepository;
    }

    /**
     * Método que prepara el contexto del modelo para agregar valores de categoría.
     * @param model El modelo para agregar los valores de categoría.
     */
    @ModelAttribute
    public void prepareContext(final Model model) {
        model.addAttribute("categoriaValues", categoriaRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Categoria::getId, Categoria::getNombre)));
    }

    /**
     * Método para mostrar la lista de cursos.
     * @param model El modelo para pasar datos a la vista.
     * @return La vista de la lista de cursos.
     */
    @GetMapping
    public String list(final Model model) {
        model.addAttribute("cursoes", cursoService.findAll());
        return "curso/list";
    }

    /**
     * Método para mostrar el formulario de añadir curso.
     * @param cursoDTO El DTO del curso para la vista.
     * @return La vista del formulario de añadir curso.
     */
    @GetMapping("/add")
    public String add(@ModelAttribute("curso") final CursoDTO cursoDTO) {
        return "curso/add";
    }

    /**
     * Método para procesar la adición de un nuevo curso.
     * @param cursoDTO El DTO del curso a añadir.
     * @param bindingResult Resultados de la validación.
     * @param redirectAttributes Atributos para la redirección.
     * @return La vista de la lista de cursos o el formulario de añadir curso en caso de errores de validación.
     */
    @PostMapping("/add")
    public String add(@ModelAttribute("curso") @Valid final CursoDTO cursoDTO,
                      final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "curso/add";
        }
        cursoService.create(cursoDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("curso.create.success"));
        return "redirect:/cursos";
    }

    // Métodos para editar, actualizar y eliminar cursos

}
