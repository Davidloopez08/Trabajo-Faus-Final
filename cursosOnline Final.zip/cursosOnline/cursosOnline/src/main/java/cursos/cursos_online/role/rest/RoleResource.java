package cursos.cursos_online.role.rest;

import cursos.cursos_online.role.model.RoleDTO;
import cursos.cursos_online.role.service.RoleService;
import cursos.cursos_online.util.ReferencedException;
import cursos.cursos_online.util.ReferencedWarning;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for managing Role entities.
 */
@RestController
@RequestMapping(value = "/api/roles", produces = MediaType.APPLICATION_JSON_VALUE)
public class RoleResource {

    private final RoleService roleService;

    public RoleResource(final RoleService roleService) {
        this.roleService = roleService;
    }

    /**
     * GET /api/roles : Get all roles.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of roles in the body
     */
    @GetMapping
    public ResponseEntity<List<RoleDTO>> getAllRoles() {
        return ResponseEntity.ok(roleService.findAll());
    }

    /**
     * GET /api/roles/{id} : Get a role by id.
     *
     * @param id the id of the role to retrieve
     * @return the ResponseEntity with status 200 (OK) and the role in the body, or with status 404 (Not Found)
     */
    @GetMapping("/{id}")
    public ResponseEntity<RoleDTO> getRole(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(roleService.get(id));
    }

    /**
     * POST /api/roles : Create a new role.
     *
     * @param roleDTO the roleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new role id, or with status 400 (Bad Request) if the roleDTO is not valid
     */
    @PostMapping
    public ResponseEntity<Integer> createRole(@RequestBody @Valid final RoleDTO roleDTO) {
        final Integer createdId = roleService.create(roleDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    /**
     * PUT /api/roles/{id} : Update an existing role.
     *
     * @param id      the id of the role to update
     * @param roleDTO the roleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated role id, or with status 400 (Bad Request) if the roleDTO is not valid
     */
    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateRole(@PathVariable(name = "id") final Integer id,
                                              @RequestBody @Valid final RoleDTO roleDTO) {
        roleService.update(id, roleDTO);
        return ResponseEntity.ok(id);
    }

    /**
     * DELETE /api/roles/{id} : Delete a role by id.
     *
     * @param id the id of the role to delete
     * @return the ResponseEntity with status 204 (No Content)
     * @throws ReferencedException if the role is referenced by other entities
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRole(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = roleService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        roleService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
