package cursos.cursos_online.perfil.controller;

import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.inscripcione.repos.InscripcioneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import cursos.cursos_online.usuario.domain.Usuario;
import cursos.cursos_online.usuario.model.UsuarioDTO;
import cursos.cursos_online.usuario.repos.UsuarioRepository;
import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.inscripcione.repos.InscripcioneRepository;
import jakarta.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller class for managing user profile-related operations.
 */
@Controller
public class perfilController {

    private UsuarioRepository usuarioRepository;
    private InscripcioneRepository inscripcionRepository;

    /**
     * Constructor for perfilController.
     *
     * @param usuarioRepository      The repository for managing Usuario entities.
     * @param inscripcionRepository The repository for managing Inscripcione entities.
     */
    @Autowired
    public perfilController(UsuarioRepository usuarioRepository, InscripcioneRepository inscripcionRepository) {
        this.usuarioRepository = usuarioRepository;
        this.inscripcionRepository = inscripcionRepository;
    }

    /**
     * Returns the view name for the user profile page.
     *
     * @return The view name for the user profile page.
     */
    @GetMapping("/perfil")
    public String inicioSesion() {
        return "/perfil/index";
    }

    /**
     * Displays the list of courses associated with the user profile.
     *
     * @param session The HTTP session.
     * @param model   The model to be used in the view.
     * @return The view name for displaying the list of courses associated with the user profile.
     */
    @GetMapping("/perfil/cursos")
    public String index(HttpSession session, Model model) {
        // Obtener el usuario actual de la sesión
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario != null) {
            // Obtener las inscripciones del usuario
            List<Inscripcione> inscripciones = inscripcionRepository.findByUsuario(usuario);

            // Lista para almacenar los cursos inscritos
            List<Curso> cursosInscritos = new ArrayList<>();

            // Obtener los cursos asociados a cada inscripción
            for (Inscripcione inscripcion : inscripciones) {
                cursosInscritos.add(inscripcion.getCurso());
            }

            // Convertir el usuario a DTO si es necesario
            UsuarioDTO usuarioDTO = new UsuarioDTO(); // Suponiendo que tienes un DTO para Usuario
            // Aquí puedes agregar cualquier otra información que necesites al DTO

            model.addAttribute("usuario", usuarioDTO);
            model.addAttribute("cursosInscritos", cursosInscritos);

            return "/perfil/index";
        } else {
            // Redirigir al usuario a la página de inicio de sesión si no hay un usuario en la sesión
            return "redirect:/inicioSesion";
        }
    }
}
