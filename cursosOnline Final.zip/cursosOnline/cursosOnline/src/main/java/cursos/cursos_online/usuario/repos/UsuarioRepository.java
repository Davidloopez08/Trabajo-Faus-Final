package cursos.cursos_online.usuario.repos;

import cursos.cursos_online.role.domain.Role;
import cursos.cursos_online.usuario.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository interface for managing Usuario entities.
 */
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    /**
     * Finds the first Usuario associated with the given Role.
     *
     * @param role The Role to search for.
     * @return The first Usuario associated with the given Role, or null if none found.
     */
    Usuario findFirstByRol(Role role);

    /**
     * Finds a Usuario by its name and password.
     *
     * @param nombre     The name of the Usuario.
     * @param contrasena The password of the Usuario.
     * @return The Usuario with the given name and password, or null if none found.
     */
    Usuario findByNombreAndContrasena(String nombre, String contrasena);

    /**
     * Finds a Usuario by its ID.
     *
     * @param id The ID of the Usuario to find.
     * @return The Usuario with the given ID, or null if none found.
     */
    Usuario findById(int id);

    /**
     * Finds a Usuario by its name.
     *
     * @param nombre The name of the Usuario to find.
     * @return The Usuario with the given name, or null if none found.
     */
    Usuario findByNombre(String nombre);
}
