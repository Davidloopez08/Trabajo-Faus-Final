package cursos.cursos_online.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Configuración de dominio para la aplicación.
 * Escanea las entidades y los repositorios JPA, y habilita la gestión de transacciones.
 */
@Configuration
@EntityScan("cursos.cursos_online") // Escanea el paquete para entidades JPA
@EnableJpaRepositories("cursos.cursos_online") // Escanea el paquete para repositorios JPA
@EnableTransactionManagement // Habilita la gestión de transacciones
public class DomainConfig {
}
