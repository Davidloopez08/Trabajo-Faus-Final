package cursos.cursos_online.usuario.controller;

import cursos.cursos_online.role.domain.Role;
import cursos.cursos_online.role.repos.RoleRepository;
import cursos.cursos_online.usuario.model.UsuarioDTO;
import cursos.cursos_online.usuario.service.UsuarioService;
import cursos.cursos_online.util.CustomCollectors;
import cursos.cursos_online.util.ReferencedWarning;
import cursos.cursos_online.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Controller class for managing Usuario entities.
 */
@Controller
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;
    private final RoleRepository roleRepository;

    public UsuarioController(final UsuarioService usuarioService,
                             final RoleRepository roleRepository) {
        this.usuarioService = usuarioService;
        this.roleRepository = roleRepository;
    }

    /**
     * Populate the model with data needed for the view.
     *
     * @param model the model to populate
     */
    @ModelAttribute
    public void prepareContext(final Model model) {
        model.addAttribute("rolValues", roleRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Role::getId, Role::getRol)));
    }

    /**
     * Display a list of usuarios.
     *
     * @param model the model to populate
     * @return the view name
     */
    @GetMapping
    public String list(final Model model) {
        model.addAttribute("usuarios", usuarioService.findAll());
        return "usuario/list";
    }

    /**
     * Display the form for adding a new usuario.
     *
     * @param usuarioDTO the usuario DTO to bind to the form
     * @return the view name
     */
    @GetMapping("/add")
    public String add(@ModelAttribute("usuario") final UsuarioDTO usuarioDTO) {
        return "usuario/add";
    }

    /**
     * Process the submission of a new usuario.
     *
     * @param usuarioDTO          the usuario DTO submitted
     * @param bindingResult       the result of the binding
     * @param redirectAttributes the redirect attributes
     * @return the redirect view name
     */
    @PostMapping("/add")
    public String add(@ModelAttribute("usuario") @Valid final UsuarioDTO usuarioDTO,
                      final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "usuario/add";
        }
        usuarioService.create(usuarioDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("usuario.create.success"));
        return "redirect:/inicioSesion";
    }

    /**
     * Display the form for editing a usuario.
     *
     * @param id    the id of the usuario to edit
     * @param model the model to populate
     * @return the view name
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id, final Model model) {
        model.addAttribute("usuario", usuarioService.get(id));
        return "usuario/edit";
    }

    /**
     * Process the submission of editing a usuario.
     *
     * @param id                  the id of the usuario to edit
     * @param usuarioDTO          the usuario DTO submitted
     * @param bindingResult       the result of the binding
     * @param redirectAttributes the redirect attributes
     * @return the redirect view name
     */
    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id,
                       @ModelAttribute("usuario") @Valid final UsuarioDTO usuarioDTO,
                       final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "usuario/edit";
        }
        usuarioService.update(id, usuarioDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("usuario.update.success"));
        return "redirect:/usuarios";
    }

    /**
     * Process the deletion of a usuario.
     *
     * @param id                  the id of the usuario to delete
     * @param redirectAttributes the redirect attributes
     * @return the redirect view name
     */
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Integer id,
                         final RedirectAttributes redirectAttributes) {
        final ReferencedWarning referencedWarning = usuarioService.getReferencedWarning(id);
        if (referencedWarning != null) {
            redirectAttributes.addFlashAttribute(WebUtils.MSG_ERROR,
                    WebUtils.getMessage(referencedWarning.getKey(), referencedWarning.getParams().toArray()));
        } else {
            usuarioService.delete(id);
            redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("usuario.delete.success"));
        }
        return "redirect:/usuarios";
    }

}
