package cursos.cursos_online.leccione.repos;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.leccione.domain.Leccione;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository interface for interacting with lesson entities in the database.
 */
public interface LeccioneRepository extends JpaRepository<Leccione, Integer> {

    /**
     * Finds the first lesson associated with the given course.
     *
     * @param curso The course to find the lesson for.
     * @return The first lesson associated with the given course.
     */
    Leccione findFirstByCurso(Curso curso);

}
