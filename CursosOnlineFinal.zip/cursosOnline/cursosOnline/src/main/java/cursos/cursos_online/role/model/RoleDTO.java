package cursos.cursos_online.role.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * Data Transfer Object (DTO) for Role entity.
 */
@Getter
@Setter
public class RoleDTO {

    private Integer id;

    @NotNull
    @Size(max = 50)
    private String rol;

}
