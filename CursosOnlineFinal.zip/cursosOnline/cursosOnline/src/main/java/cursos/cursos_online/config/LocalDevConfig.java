package cursos.cursos_online.config;

import java.io.File;
import lombok.SneakyThrows;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templateresolver.FileTemplateResolver;

/**
 * Configuración específica para el entorno de desarrollo local.
 * Carga archivos Thymeleaf desde el sistema de archivos durante el desarrollo, sin ningún almacenamiento en caché.
 */
@Configuration
@Profile("local")
public class LocalDevConfig {

    /**
     * Constructor que configura el motor de plantillas Thymeleaf para cargar archivos desde el sistema de archivos local durante el desarrollo.
     * @param templateEngine El motor de plantillas Thymeleaf.
     */
    @SneakyThrows
    public LocalDevConfig(final TemplateEngine templateEngine) {
        // Busca el archivo application.properties en la clase de ruta y obtiene la ruta del directorio fuente
        final ClassPathResource applicationProperties = new ClassPathResource("application.properties");
        if (applicationProperties.isFile()) {
            File sourceRoot = applicationProperties.getFile().getParentFile();
            while (sourceRoot.listFiles((dir, name) -> name.equals("mvnw")).length != 1) {
                sourceRoot = sourceRoot.getParentFile();
            }
            // Configura un resolutor de plantillas Thymeleaf para cargar plantillas desde el directorio de recursos
            final FileTemplateResolver fileTemplateResolver = new FileTemplateResolver();
            fileTemplateResolver.setPrefix(sourceRoot.getPath() + "/src/main/resources/templates/");
            fileTemplateResolver.setSuffix(".html");
            fileTemplateResolver.setCacheable(false);
            fileTemplateResolver.setCharacterEncoding("UTF-8");
            fileTemplateResolver.setCheckExistence(true);
            // Configura el motor de plantillas Thymeleaf para usar el resolutor de plantillas personalizado
            templateEngine.setTemplateResolver(fileTemplateResolver);
        }
    }

}
