package cursos.cursos_online.inscripcione.service;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.curso.repos.CursoRepository;
import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.inscripcione.model.InscripcioneDTO;
import cursos.cursos_online.inscripcione.repos.InscripcioneRepository;
import cursos.cursos_online.usuario.domain.Usuario;
import cursos.cursos_online.usuario.repos.UsuarioRepository;
import cursos.cursos_online.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

/**
 * Service class for managing inscriptions.
 */
@Service
public class InscripcioneService {

    private final InscripcioneRepository inscripcioneRepository;
    private final UsuarioRepository usuarioRepository;
    private final CursoRepository cursoRepository;

    public InscripcioneService(InscripcioneRepository inscripcionRepository,
                               UsuarioRepository usuarioRepository,
                               CursoRepository cursoRepository) {
        this.inscripcioneRepository = inscripcionRepository;
        this.usuarioRepository = usuarioRepository;
        this.cursoRepository = cursoRepository;
    }

    /**
     * Retrieves all inscriptions.
     *
     * @return List of InscripcioneDTOs.
     */
    public List<InscripcioneDTO> findAll() {
        final List<Inscripcione> inscripciones = inscripcioneRepository.findAll(Sort.by("id"));
        return inscripciones.stream()
                .map(inscripcione -> mapToDTO(inscripcione, new InscripcioneDTO()))
                .toList();
    }

    /**
     * Retrieves an inscription by its ID.
     *
     * @param id The ID of the inscription to retrieve.
     * @return InscripcioneDTO corresponding to the ID.
     * @throws NotFoundException if the inscription with the given ID is not found.
     */
    public InscripcioneDTO get(final Integer id) {
        return inscripcioneRepository.findById(id)
                .map(inscripcione -> mapToDTO(inscripcione, new InscripcioneDTO()))
                .orElseThrow(NotFoundException::new);
    }

    /**
     * Creates a new inscription.
     *
     * @param inscripcioneDTO The InscripcioneDTO containing the data of the new inscription.
     * @return The ID of the created inscription.
     */
    public Integer create(final InscripcioneDTO inscripcioneDTO) {
        final Inscripcione inscripcione = new Inscripcione();
        mapToEntity(inscripcioneDTO, inscripcione);
        return inscripcioneRepository.save(inscripcione).getId();
    }

    /**
     * Updates an existing inscription.
     *
     * @param id The ID of the inscription to update.
     * @param inscripcioneDTO The InscripcioneDTO containing the updated data.
     * @throws NotFoundException if the inscription with the given ID is not found.
     */
    public void update(final Integer id, final InscripcioneDTO inscripcioneDTO) {
        final Inscripcione inscripcione = inscripcioneRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(inscripcioneDTO, inscripcione);
        inscripcioneRepository.save(inscripcione);
    }

    /**
     * Deletes an inscription by its ID.
     *
     * @param id The ID of the inscription to delete.
     */
    public void delete(final Integer id) {
        inscripcioneRepository.deleteById(id);
    }

    private InscripcioneDTO mapToDTO(final Inscripcione inscripcione,
                                     final InscripcioneDTO inscripcioneDTO) {
        inscripcioneDTO.setId(inscripcione.getId());
        inscripcioneDTO.setFechaInscripcion(inscripcione.getFechaInscripcion());
        inscripcioneDTO.setUsuario(inscripcione.getUsuario() == null ? null : inscripcione.getUsuario().getId());
        inscripcioneDTO.setCurso(inscripcione.getCurso() == null ? null : inscripcione.getCurso().getId());
        return inscripcioneDTO;
    }

    private Inscripcione mapToEntity(final InscripcioneDTO inscripcioneDTO,
                                     final Inscripcione inscripcione) {
        inscripcione.setFechaInscripcion(inscripcioneDTO.getFechaInscripcion());
        final Usuario usuario = inscripcioneDTO.getUsuario() == null ? null : usuarioRepository.findById(inscripcioneDTO.getUsuario())
                .orElseThrow(() -> new NotFoundException("usuario not found"));
        inscripcione.setUsuario(usuario);
        final Curso curso = inscripcioneDTO.getCurso() == null ? null : cursoRepository.findById(inscripcioneDTO.getCurso())
                .orElseThrow(() -> new NotFoundException("curso not found"));
        inscripcione.setCurso(curso);
        return inscripcione;
    }
}
