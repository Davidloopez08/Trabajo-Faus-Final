package cursos.cursos_online.usuario.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

/**
 * Data transfer object (DTO) for representing Usuario information.
 */
@Getter
@Setter
public class UsuarioDTO {

    /**
     * The unique identifier of the user.
     */
    private Integer id;

    /**
     * The name of the user.
     */
    @NotNull
    @Size(max = 50)
    private String nombre;

    /**
     * The age of the user.
     */
    private Integer edad;

    /**
     * The email address of the user.
     */
    @Size(max = 100)
    private String correo;

    /**
     * The phone number of the user.
     */
    @Size(max = 15)
    private String telefono;

    /**
     * The password of the user.
     */
    @Size(max = 50)
    private String contrasena;

    /**
     * The role ID associated with the user.
     */
    private Integer rol;

}
