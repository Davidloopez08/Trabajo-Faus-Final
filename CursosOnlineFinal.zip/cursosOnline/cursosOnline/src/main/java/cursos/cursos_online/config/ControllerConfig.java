package cursos.cursos_online.config;

import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;

/**
 * Clase de configuración global para los controladores.
 * Permite configurar los binder para preprocesar los datos recibidos por los controladores.
 */
@ControllerAdvice
public class ControllerConfig {

    /**
     * Configura el binder para eliminar los espacios en blanco de los Strings.
     * @param binder El objeto WebDataBinder a configurar.
     */
    @InitBinder
    public void initBinder(final WebDataBinder binder) {
        binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
    }

}
