package cursos.cursos_online.categoria.repos;

import cursos.cursos_online.categoria.domain.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio para la entidad Categoria.
 * Proporciona métodos para realizar operaciones de base de datos relacionadas con la entidad Categoria.
 */
public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}
