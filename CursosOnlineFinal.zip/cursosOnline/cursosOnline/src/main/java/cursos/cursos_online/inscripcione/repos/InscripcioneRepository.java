package cursos.cursos_online.inscripcione.repos;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.usuario.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Repository interface for performing database operations related to Inscripcione entities.
 */
public interface InscripcioneRepository extends JpaRepository<Inscripcione, Integer> {

    /**
     * Retrieves the first inscription associated with the specified user.
     *
     * @param usuario The user entity.
     * @return The first Inscripcione associated with the user.
     */
    Inscripcione findFirstByUsuario(Usuario usuario);

    /**
     * Retrieves the first inscription associated with the specified course.
     *
     * @param curso The course entity.
     * @return The first Inscripcione associated with the course.
     */
    Inscripcione findFirstByCurso(Curso curso);

    /**
     * Retrieves a list of inscriptions associated with the specified user.
     *
     * @param usuario The user entity.
     * @return A list of Inscripcione associated with the user.
     */
    List<Inscripcione> findByUsuario(Usuario usuario);
}
