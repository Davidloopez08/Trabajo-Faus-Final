package cursos.cursos_online.leccione.rest;

import cursos.cursos_online.leccione.model.LeccioneDTO;
import cursos.cursos_online.leccione.service.LeccioneService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for managing lesson resources.
 */
@RestController
@RequestMapping(value = "/api/lecciones", produces = MediaType.APPLICATION_JSON_VALUE)
public class LeccioneResource {

    private final LeccioneService leccioneService;

    public LeccioneResource(final LeccioneService leccioneService) {
        this.leccioneService = leccioneService;
    }

    /**
     * Retrieves all lessons.
     *
     * @return ResponseEntity containing a list of lesson DTOs
     */
    @GetMapping
    public ResponseEntity<List<LeccioneDTO>> getAllLecciones() {
        return ResponseEntity.ok(leccioneService.findAll());
    }

    /**
     * Retrieves a lesson by its ID.
     *
     * @param id The ID of the lesson to retrieve
     * @return ResponseEntity containing the lesson DTO
     */
    @GetMapping("/{id}")
    public ResponseEntity<LeccioneDTO> getLeccione(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(leccioneService.get(id));
    }

    /**
     * Creates a new lesson.
     *
     * @param leccioneDTO The DTO representing the lesson to be created
     * @return ResponseEntity containing the ID of the created lesson
     */
    @PostMapping
    public ResponseEntity<Integer> createLeccione(
            @RequestBody @Valid final LeccioneDTO leccioneDTO) {
        final Integer createdId = leccioneService.create(leccioneDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    /**
     * Updates an existing lesson.
     *
     * @param id The ID of the lesson to update
     * @param leccioneDTO The DTO representing the updated lesson data
     * @return ResponseEntity indicating success
     */
    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateLeccione(@PathVariable(name = "id") final Integer id,
                                                  @RequestBody @Valid final LeccioneDTO leccioneDTO) {
        leccioneService.update(id, leccioneDTO);
        return ResponseEntity.ok(id);
    }

    /**
     * Deletes a lesson by its ID.
     *
     * @param id The ID of the lesson to delete
     * @return ResponseEntity indicating success
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLeccione(@PathVariable(name = "id") final Integer id) {
        leccioneService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
