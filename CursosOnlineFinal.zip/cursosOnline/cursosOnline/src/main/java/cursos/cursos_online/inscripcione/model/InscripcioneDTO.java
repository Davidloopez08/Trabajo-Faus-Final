package cursos.cursos_online.inscripcione.model;

import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * Data Transfer Object (DTO) for representing an inscription in the system.
 */
@Getter
@Setter
public class InscripcioneDTO {

    /**
     * The unique identifier for the inscription.
     */
    private Integer id;

    /**
     * The date and time when the inscription was made.
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private OffsetDateTime fechaInscripcion;

    /**
     * The ID of the user who made the inscription.
     */
    private Integer usuario;

    /**
     * The ID of the course to which the user is enrolled.
     */
    private Integer curso;

}
