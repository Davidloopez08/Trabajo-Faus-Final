package cursos.cursos_online.curso.domain;

import cursos.cursos_online.categoria.domain.Categoria;
import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.leccione.domain.Leccione;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import java.time.LocalDate;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Curso {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(columnDefinition = "longtext")
    private String descripcion;

    @Column
    private LocalDate fechaInicio;

    @Column
    private LocalDate fechaFin;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

    @OneToMany(mappedBy = "curso")
    private Set<Inscripcione> cursoInscripciones;

    @OneToMany(mappedBy = "curso")
    private Set<Leccione> cursoLecciones;
}
