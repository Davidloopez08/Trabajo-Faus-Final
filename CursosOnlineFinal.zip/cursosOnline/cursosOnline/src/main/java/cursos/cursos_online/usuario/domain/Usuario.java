package cursos.cursos_online.usuario.domain;

import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.role.domain.Role;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Represents a Usuario entity in the system.
 */
@Entity
@Getter
@Setter
public class Usuario {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * The name of the user.
     */
    @Column(nullable = false, length = 50)
    private String nombre;

    /**
     * The age of the user.
     */
    @Column
    private Integer edad;

    /**
     * The email address of the user.
     */
    @Column(length = 100)
    private String correo;

    /**
     * The phone number of the user.
     */
    @Column(length = 15)
    private String telefono;

    /**
     * The password of the user.
     */
    @Column(length = 50)
    private String contrasena;

    /**
     * The role associated with the user.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "rol_id")
    public Role rol;

    /**
     * The set of inscriptions associated with the user.
     */
    @OneToMany(mappedBy = "usuario", fetch = FetchType.EAGER)
    private Set<Inscripcione> usuarioInscripciones;

    /**
     * Returns a string representation of the Usuario object.
     *
     * @return a string representation of the Usuario object.
     */
    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", correo='" + correo + '\'' +
                ", telefono='" + telefono + '\'' +
                ", contrasena='" + contrasena + '\'' +
                ", rol=" + rol +
                ", usuarioInscripciones=" + usuarioInscripciones +
                '}';
    }
}
