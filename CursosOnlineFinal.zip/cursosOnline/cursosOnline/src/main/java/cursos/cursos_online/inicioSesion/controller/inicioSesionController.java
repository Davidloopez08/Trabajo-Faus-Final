package cursos.cursos_online.inicioSesion.controller;

import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.usuario.domain.Usuario;
import cursos.cursos_online.usuario.repos.UsuarioRepository;
import cursos.cursos_online.usuario.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Set;

/**
 * Controlador para gestionar el inicio de sesión de usuarios.
 */
@Controller
public class inicioSesionController {

    private UsuarioRepository userRepository;
    private UsuarioService usuarioService;

    @Autowired
    public inicioSesionController(UsuarioRepository userRepository, UsuarioService usuarioService) {
        this.userRepository = userRepository;
        this.usuarioService = usuarioService;
    }

    /**
     * Maneja las solicitudes GET para la página de inicio de sesión.
     * @return La vista de la página de inicio de sesión.
     */
    @GetMapping("/inicioSesion")
    public String inicioSesion() {
        return "/inicioSesion/index";
    }

    /**
     * Maneja las solicitudes POST para el inicio de sesión.
     * @param nombre El nombre de usuario.
     * @param contrasena La contraseña del usuario.
     * @param session La sesión HTTP.
     * @param model El modelo para agregar atributos.
     * @return La página de perfil si el inicio de sesión es exitoso, de lo contrario, redirige a la página de inicio de sesión.
     */
    @PostMapping("/login")
    public String login(
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String contrasena, HttpSession session, Model model) {
        // Verificar las credenciales
        Usuario user = userRepository.findByNombreAndContrasena(nombre, contrasena);
        if (user != null) {
            model.addAttribute("usuario", user);
            Set<Inscripcione> inscripciones = user.getUsuarioInscripciones();
            model.addAttribute("inscripciones", inscripciones);

            // Redireccionar al usuario a la página deseada
            return "/perfil/index";
        } else {
            return "redirect:/inicioSesion"; // Aquí asumiendo que el nombre de tu página de inicio de sesión es "login"
        }
    }
}
