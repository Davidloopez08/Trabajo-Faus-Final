package cursos.cursos_online.curso.repos;

import cursos.cursos_online.categoria.domain.Categoria;
import cursos.cursos_online.curso.domain.Curso;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

/**
 * Repositorio para acceder a los datos de los cursos.
 * Proporciona métodos para realizar operaciones CRUD (Crear, Leer, Actualizar, Eliminar) en la entidad Curso.
 */
public interface CursoRepository extends JpaRepository<Curso, Integer> {

    /**
     * Encuentra el primer curso asociado a una categoría específica.
     * @param categoria La categoría para la cual se busca el curso.
     * @return El primer curso asociado a la categoría especificada, o null si no se encuentra ninguno.
     */
    Curso findFirstByCategoria(Categoria categoria);

}
