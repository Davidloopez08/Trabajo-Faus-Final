package cursos.cursos_online.leccione.controller;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.curso.repos.CursoRepository;
import cursos.cursos_online.leccione.model.LeccioneDTO;
import cursos.cursos_online.leccione.service.LeccioneService;
import cursos.cursos_online.util.CustomCollectors;
import cursos.cursos_online.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/lecciones")
public class LeccioneController {

    private final LeccioneService leccioneService;
    private final CursoRepository cursoRepository;

    public LeccioneController(final LeccioneService leccioneService,
            final CursoRepository cursoRepository) {
        this.leccioneService = leccioneService;
        this.cursoRepository = cursoRepository;
    }

    @ModelAttribute
    public void prepareContext(final Model model) {
        model.addAttribute("cursoValues", cursoRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Curso::getId, Curso::getNombre)));
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("lecciones", leccioneService.findAll());
        return "leccione/list";
    }

    @GetMapping("/add")
    public String add(@ModelAttribute("leccione") final LeccioneDTO leccioneDTO) {
        return "leccione/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("leccione") @Valid final LeccioneDTO leccioneDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "leccione/add";
        }
        leccioneService.create(leccioneDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("leccione.create.success"));
        return "redirect:/lecciones";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id, final Model model) {
        model.addAttribute("leccione", leccioneService.get(id));
        return "leccione/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id,
            @ModelAttribute("leccione") @Valid final LeccioneDTO leccioneDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "leccione/edit";
        }
        leccioneService.update(id, leccioneDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("leccione.update.success"));
        return "redirect:/lecciones";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Integer id,
            final RedirectAttributes redirectAttributes) {
        leccioneService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("leccione.delete.success"));
        return "redirect:/lecciones";
    }

}
