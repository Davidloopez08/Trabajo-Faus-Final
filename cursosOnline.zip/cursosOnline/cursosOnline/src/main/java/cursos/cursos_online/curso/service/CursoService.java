package cursos.cursos_online.curso.service;

import cursos.cursos_online.categoria.domain.Categoria;
import cursos.cursos_online.categoria.repos.CategoriaRepository;
import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.curso.model.CursoDTO;
import cursos.cursos_online.curso.repos.CursoRepository;
import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.inscripcione.repos.InscripcioneRepository;
import cursos.cursos_online.leccione.domain.Leccione;
import cursos.cursos_online.leccione.repos.LeccioneRepository;
import cursos.cursos_online.util.NotFoundException;
import cursos.cursos_online.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class CursoService {

    private final CursoRepository cursoRepository;
    private final CategoriaRepository categoriaRepository;
    private final InscripcioneRepository inscripcioneRepository;
    private final LeccioneRepository leccioneRepository;

    public CursoService(final CursoRepository cursoRepository,
            final CategoriaRepository categoriaRepository,
            final InscripcioneRepository inscripcioneRepository,
            final LeccioneRepository leccioneRepository) {
        this.cursoRepository = cursoRepository;
        this.categoriaRepository = categoriaRepository;
        this.inscripcioneRepository = inscripcioneRepository;
        this.leccioneRepository = leccioneRepository;
    }

    public List<CursoDTO> findAll() {
        final List<Curso> cursoes = cursoRepository.findAll(Sort.by("id"));
        return cursoes.stream()
                .map(curso -> mapToDTO(curso, new CursoDTO()))
                .toList();
    }

    public CursoDTO get(final Integer id) {
        return cursoRepository.findById(id)
                .map(curso -> mapToDTO(curso, new CursoDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final CursoDTO cursoDTO) {
        final Curso curso = new Curso();
        mapToEntity(cursoDTO, curso);
        return cursoRepository.save(curso).getId();
    }

    public void update(final Integer id, final CursoDTO cursoDTO) {
        final Curso curso = cursoRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(cursoDTO, curso);
        cursoRepository.save(curso);
    }

    public void delete(final Integer id) {
        cursoRepository.deleteById(id);
    }

    private CursoDTO mapToDTO(final Curso curso, final CursoDTO cursoDTO) {
        cursoDTO.setId(curso.getId());
        cursoDTO.setNombre(curso.getNombre());
        cursoDTO.setDescripcion(curso.getDescripcion());
        cursoDTO.setFechaInicio(curso.getFechaInicio());
        cursoDTO.setFechaFin(curso.getFechaFin());
        cursoDTO.setCategoria(curso.getCategoria() == null ? null : curso.getCategoria().getId());
        return cursoDTO;
    }

    private Curso mapToEntity(final CursoDTO cursoDTO, final Curso curso) {
        curso.setNombre(cursoDTO.getNombre());
        curso.setDescripcion(cursoDTO.getDescripcion());
        curso.setFechaInicio(cursoDTO.getFechaInicio());
        curso.setFechaFin(cursoDTO.getFechaFin());
        final Categoria categoria = cursoDTO.getCategoria() == null ? null : categoriaRepository.findById(cursoDTO.getCategoria())
                .orElseThrow(() -> new NotFoundException("categoria not found"));
        curso.setCategoria(categoria);
        return curso;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Curso curso = cursoRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Inscripcione cursoInscripcione = inscripcioneRepository.findFirstByCurso(curso);
        if (cursoInscripcione != null) {
            referencedWarning.setKey("curso.inscripcione.curso.referenced");
            referencedWarning.addParam(cursoInscripcione.getId());
            return referencedWarning;
        }
        final Leccione cursoLeccione = leccioneRepository.findFirstByCurso(curso);
        if (cursoLeccione != null) {
            referencedWarning.setKey("curso.leccione.curso.referenced");
            referencedWarning.addParam(cursoLeccione.getId());
            return referencedWarning;
        }
        return null;
    }

}
