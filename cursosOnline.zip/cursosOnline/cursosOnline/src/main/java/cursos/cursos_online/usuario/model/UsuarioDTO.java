package cursos.cursos_online.usuario.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class UsuarioDTO {

    private Integer id;

    @NotNull
    @Size(max = 50)
    private String nombre;

    private Integer edad;

    @Size(max = 100)
    private String correo;

    @Size(max = 15)
    private String telefono;

    @Size(max = 50)
    private String contrasena;

    private Integer rol;

}
