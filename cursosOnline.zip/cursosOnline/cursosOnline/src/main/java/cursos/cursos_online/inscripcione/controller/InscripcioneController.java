package cursos.cursos_online.inscripcione.controller;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.curso.repos.CursoRepository;
import cursos.cursos_online.inscripcione.model.InscripcioneDTO;
import cursos.cursos_online.inscripcione.service.InscripcioneService;
import cursos.cursos_online.usuario.domain.Usuario;
import cursos.cursos_online.usuario.repos.UsuarioRepository;
import cursos.cursos_online.util.CustomCollectors;
import cursos.cursos_online.util.WebUtils;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/inscripciones")
public class InscripcioneController {

    private final InscripcioneService inscripcioneService;
    private final UsuarioRepository usuarioRepository;
    private final CursoRepository cursoRepository;

    public InscripcioneController(final InscripcioneService inscripcioneService,
            final UsuarioRepository usuarioRepository, final CursoRepository cursoRepository) {
        this.inscripcioneService = inscripcioneService;
        this.usuarioRepository = usuarioRepository;
        this.cursoRepository = cursoRepository;
    }

    @ModelAttribute
    public void prepareContext(final Model model) {
        model.addAttribute("usuarioValues", usuarioRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Usuario::getId, Usuario::getNombre)));
        model.addAttribute("cursoValues", cursoRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Curso::getId, Curso::getNombre)));
    }

    @GetMapping
    public String list(final Model model) {
        model.addAttribute("inscripciones", inscripcioneService.findAll());
        return "inscripcione/list";
    }

    @GetMapping("/add")
    public String add(@ModelAttribute("inscripcione") final InscripcioneDTO inscripcioneDTO) {
        return "inscripcione/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("inscripcione") @Valid final InscripcioneDTO inscripcioneDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "inscripcione/add";
        }
        inscripcioneService.create(inscripcioneDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("inscripcione.create.success"));
        return "redirect:/inscripciones";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id, final Model model) {
        model.addAttribute("inscripcione", inscripcioneService.get(id));
        return "inscripcione/edit";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable(name = "id") final Integer id,
            @ModelAttribute("inscripcione") @Valid final InscripcioneDTO inscripcioneDTO,
            final BindingResult bindingResult, final RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "inscripcione/edit";
        }
        inscripcioneService.update(id, inscripcioneDTO);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_SUCCESS, WebUtils.getMessage("inscripcione.update.success"));
        return "redirect:/inscripciones";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable(name = "id") final Integer id,
            final RedirectAttributes redirectAttributes) {
        inscripcioneService.delete(id);
        redirectAttributes.addFlashAttribute(WebUtils.MSG_INFO, WebUtils.getMessage("inscripcione.delete.success"));
        return "redirect:/inscripciones";
    }

}
