package cursos.cursos_online.leccione.rest;

import cursos.cursos_online.leccione.model.LeccioneDTO;
import cursos.cursos_online.leccione.service.LeccioneService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/lecciones", produces = MediaType.APPLICATION_JSON_VALUE)
public class LeccioneResource {

    private final LeccioneService leccioneService;

    public LeccioneResource(final LeccioneService leccioneService) {
        this.leccioneService = leccioneService;
    }

    @GetMapping
    public ResponseEntity<List<LeccioneDTO>> getAllLecciones() {
        return ResponseEntity.ok(leccioneService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LeccioneDTO> getLeccione(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(leccioneService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createLeccione(
            @RequestBody @Valid final LeccioneDTO leccioneDTO) {
        final Integer createdId = leccioneService.create(leccioneDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateLeccione(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final LeccioneDTO leccioneDTO) {
        leccioneService.update(id, leccioneDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLeccione(@PathVariable(name = "id") final Integer id) {
        leccioneService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
