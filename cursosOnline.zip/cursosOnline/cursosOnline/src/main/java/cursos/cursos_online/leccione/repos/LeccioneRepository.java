package cursos.cursos_online.leccione.repos;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.leccione.domain.Leccione;
import org.springframework.data.jpa.repository.JpaRepository;


public interface LeccioneRepository extends JpaRepository<Leccione, Integer> {

    Leccione findFirstByCurso(Curso curso);

}
