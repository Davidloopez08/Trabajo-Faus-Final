package cursos.cursos_online.inicioSesion.controller;

import cursos.cursos_online.usuario.domain.Usuario;
import cursos.cursos_online.usuario.model.UsuarioDTO;
import cursos.cursos_online.usuario.repos.UsuarioRepository;
import cursos.cursos_online.usuario.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;


@Controller
public class inicioSesionController {

    private UsuarioRepository userRepository; // Suponiendo que tienes un repositorio para la entidad de usuario
    private UsuarioService usuarioService;

    @Autowired
    public inicioSesionController(UsuarioRepository userRepository,UsuarioService usuarioService){
        this.userRepository = userRepository;
        this.usuarioService = usuarioService;
    }
    @GetMapping("/inicioSesion")
    public String inicioSesion() {
        return "/inicioSesion/index";
    }




    @PostMapping("/login")
    public String login(
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String contraseña, HttpSession session, Model model) {
        // Verificar las credenciales
        Usuario user = userRepository.findByNombreAndContrasena(nombre, contraseña);
        if (user != null) {
            UsuarioDTO userDTO = new UsuarioDTO();
            userDTO = usuarioService.mapToDTO(user,userDTO);

            model.addAttribute("usuario",userDTO);


            // Redireccionar al usuario a la página deseada
            return "/perfil/index";
        } else {
            return "redirect:/inicioSesion"; // Aquí asumiendo que el nombre de tu página de inicio de sesión es "login"
        }
    }

}
