package cursos.cursos_online.inscripcione.service;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.curso.repos.CursoRepository;
import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.inscripcione.model.InscripcioneDTO;
import cursos.cursos_online.inscripcione.repos.InscripcioneRepository;
import cursos.cursos_online.usuario.domain.Usuario;
import cursos.cursos_online.usuario.repos.UsuarioRepository;
import cursos.cursos_online.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class InscripcioneService {

    private final InscripcioneRepository inscripcioneRepository;
    private final UsuarioRepository usuarioRepository;
    private final CursoRepository cursoRepository;

    public InscripcioneService(final InscripcioneRepository inscripcioneRepository,
            final UsuarioRepository usuarioRepository, final CursoRepository cursoRepository) {
        this.inscripcioneRepository = inscripcioneRepository;
        this.usuarioRepository = usuarioRepository;
        this.cursoRepository = cursoRepository;
    }

    public List<InscripcioneDTO> findAll() {
        final List<Inscripcione> inscripciones = inscripcioneRepository.findAll(Sort.by("id"));
        return inscripciones.stream()
                .map(inscripcione -> mapToDTO(inscripcione, new InscripcioneDTO()))
                .toList();
    }

    public InscripcioneDTO get(final Integer id) {
        return inscripcioneRepository.findById(id)
                .map(inscripcione -> mapToDTO(inscripcione, new InscripcioneDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final InscripcioneDTO inscripcioneDTO) {
        final Inscripcione inscripcione = new Inscripcione();
        mapToEntity(inscripcioneDTO, inscripcione);
        return inscripcioneRepository.save(inscripcione).getId();
    }

    public void update(final Integer id, final InscripcioneDTO inscripcioneDTO) {
        final Inscripcione inscripcione = inscripcioneRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(inscripcioneDTO, inscripcione);
        inscripcioneRepository.save(inscripcione);
    }

    public void delete(final Integer id) {
        inscripcioneRepository.deleteById(id);
    }

    private InscripcioneDTO mapToDTO(final Inscripcione inscripcione,
            final InscripcioneDTO inscripcioneDTO) {
        inscripcioneDTO.setId(inscripcione.getId());
        inscripcioneDTO.setFechaInscripcion(inscripcione.getFechaInscripcion());
        inscripcioneDTO.setUsuario(inscripcione.getUsuario() == null ? null : inscripcione.getUsuario().getId());
        inscripcioneDTO.setCurso(inscripcione.getCurso() == null ? null : inscripcione.getCurso().getId());
        return inscripcioneDTO;
    }

    private Inscripcione mapToEntity(final InscripcioneDTO inscripcioneDTO,
            final Inscripcione inscripcione) {
        inscripcione.setFechaInscripcion(inscripcioneDTO.getFechaInscripcion());
        final Usuario usuario = inscripcioneDTO.getUsuario() == null ? null : usuarioRepository.findById(inscripcioneDTO.getUsuario())
                .orElseThrow(() -> new NotFoundException("usuario not found"));
        inscripcione.setUsuario(usuario);
        final Curso curso = inscripcioneDTO.getCurso() == null ? null : cursoRepository.findById(inscripcioneDTO.getCurso())
                .orElseThrow(() -> new NotFoundException("curso not found"));
        inscripcione.setCurso(curso);
        return inscripcione;
    }

}
