package cursos.cursos_online.categoria.repos;

import cursos.cursos_online.categoria.domain.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}
