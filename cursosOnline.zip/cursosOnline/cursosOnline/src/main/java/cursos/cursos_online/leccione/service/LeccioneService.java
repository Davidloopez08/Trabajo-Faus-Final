package cursos.cursos_online.leccione.service;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.curso.repos.CursoRepository;
import cursos.cursos_online.leccione.domain.Leccione;
import cursos.cursos_online.leccione.model.LeccioneDTO;
import cursos.cursos_online.leccione.repos.LeccioneRepository;
import cursos.cursos_online.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class LeccioneService {

    private final LeccioneRepository leccioneRepository;
    private final CursoRepository cursoRepository;

    public LeccioneService(final LeccioneRepository leccioneRepository,
            final CursoRepository cursoRepository) {
        this.leccioneRepository = leccioneRepository;
        this.cursoRepository = cursoRepository;
    }

    public List<LeccioneDTO> findAll() {
        final List<Leccione> lecciones = leccioneRepository.findAll(Sort.by("id"));
        return lecciones.stream()
                .map(leccione -> mapToDTO(leccione, new LeccioneDTO()))
                .toList();
    }

    public LeccioneDTO get(final Integer id) {
        return leccioneRepository.findById(id)
                .map(leccione -> mapToDTO(leccione, new LeccioneDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final LeccioneDTO leccioneDTO) {
        final Leccione leccione = new Leccione();
        mapToEntity(leccioneDTO, leccione);
        return leccioneRepository.save(leccione).getId();
    }

    public void update(final Integer id, final LeccioneDTO leccioneDTO) {
        final Leccione leccione = leccioneRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(leccioneDTO, leccione);
        leccioneRepository.save(leccione);
    }

    public void delete(final Integer id) {
        leccioneRepository.deleteById(id);
    }

    private LeccioneDTO mapToDTO(final Leccione leccione, final LeccioneDTO leccioneDTO) {
        leccioneDTO.setId(leccione.getId());
        leccioneDTO.setNombre(leccione.getNombre());
        leccioneDTO.setDescripcion(leccione.getDescripcion());
        leccioneDTO.setCurso(leccione.getCurso() == null ? null : leccione.getCurso().getId());
        return leccioneDTO;
    }

    private Leccione mapToEntity(final LeccioneDTO leccioneDTO, final Leccione leccione) {
        leccione.setNombre(leccioneDTO.getNombre());
        leccione.setDescripcion(leccioneDTO.getDescripcion());
        final Curso curso = leccioneDTO.getCurso() == null ? null : cursoRepository.findById(leccioneDTO.getCurso())
                .orElseThrow(() -> new NotFoundException("curso not found"));
        leccione.setCurso(curso);
        return leccione;
    }

}
