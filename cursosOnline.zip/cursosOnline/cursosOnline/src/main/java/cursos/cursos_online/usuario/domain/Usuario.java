package cursos.cursos_online.usuario.domain;

import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.role.domain.Role;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
public class Usuario {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 50)
    private String nombre;

    @Column
    private Integer edad;

    @Column(length = 100)
    private String correo;

    @Column(length = 15)
    private String telefono;

    @Column(length = 50)
    private String contraseA;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "rol_id")
    private Role rol;

    @OneToMany(mappedBy = "usuario")
    private Set<Inscripcione> usuarioInscripciones;

}
