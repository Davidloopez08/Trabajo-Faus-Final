package cursos.cursos_online.inscripcione.repos;

import cursos.cursos_online.curso.domain.Curso;
import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.usuario.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;


public interface InscripcioneRepository extends JpaRepository<Inscripcione, Integer> {

    Inscripcione findFirstByUsuario(Usuario usuario);

    Inscripcione findFirstByCurso(Curso curso);

}
