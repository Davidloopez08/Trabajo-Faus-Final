package cursos.cursos_online.usuario.repos;

import cursos.cursos_online.role.domain.Role;
import cursos.cursos_online.usuario.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    Usuario findFirstByRol(Role role);

}
