package cursos.cursos_online.leccione.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class LeccioneDTO {

    private Integer id;

    @NotNull
    @Size(max = 100)
    private String nombre;

    private String descripcion;

    private Integer curso;

}
