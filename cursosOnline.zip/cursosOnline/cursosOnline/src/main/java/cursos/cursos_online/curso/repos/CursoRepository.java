package cursos.cursos_online.curso.repos;

import cursos.cursos_online.categoria.domain.Categoria;
import cursos.cursos_online.curso.domain.Curso;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CursoRepository extends JpaRepository<Curso, Integer> {

    Curso findFirstByCategoria(Categoria categoria);

}
