package cursos.cursos_online.usuario.service;

import cursos.cursos_online.inscripcione.domain.Inscripcione;
import cursos.cursos_online.inscripcione.repos.InscripcioneRepository;
import cursos.cursos_online.role.domain.Role;
import cursos.cursos_online.role.repos.RoleRepository;
import cursos.cursos_online.usuario.domain.Usuario;
import cursos.cursos_online.usuario.model.UsuarioDTO;
import cursos.cursos_online.usuario.repos.UsuarioRepository;
import cursos.cursos_online.util.NotFoundException;
import cursos.cursos_online.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final RoleRepository roleRepository;
    private final InscripcioneRepository inscripcioneRepository;

    public UsuarioService(final UsuarioRepository usuarioRepository,
            final RoleRepository roleRepository,
            final InscripcioneRepository inscripcioneRepository) {
        this.usuarioRepository = usuarioRepository;
        this.roleRepository = roleRepository;
        this.inscripcioneRepository = inscripcioneRepository;
    }

    public List<UsuarioDTO> findAll() {
        final List<Usuario> usuarios = usuarioRepository.findAll(Sort.by("id"));
        return usuarios.stream()
                .map(usuario -> mapToDTO(usuario, new UsuarioDTO()))
                .toList();
    }

    public UsuarioDTO get(final Integer id) {
        return usuarioRepository.findById(id)
                .map(usuario -> mapToDTO(usuario, new UsuarioDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final UsuarioDTO usuarioDTO) {
        final Usuario usuario = new Usuario();
        mapToEntity(usuarioDTO, usuario);
        return usuarioRepository.save(usuario).getId();
    }

    public void update(final Integer id, final UsuarioDTO usuarioDTO) {
        final Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(usuarioDTO, usuario);
        usuarioRepository.save(usuario);
    }

    public void delete(final Integer id) {
        usuarioRepository.deleteById(id);
    }

    private UsuarioDTO mapToDTO(final Usuario usuario, final UsuarioDTO usuarioDTO) {
        usuarioDTO.setId(usuario.getId());
        usuarioDTO.setNombre(usuario.getNombre());
        usuarioDTO.setEdad(usuario.getEdad());
        usuarioDTO.setCorreo(usuario.getCorreo());
        usuarioDTO.setTelefono(usuario.getTelefono());
        usuarioDTO.setContraseA(usuario.getContraseA());
        usuarioDTO.setRol(usuario.getRol() == null ? null : usuario.getRol().getId());
        return usuarioDTO;
    }

    private Usuario mapToEntity(final UsuarioDTO usuarioDTO, final Usuario usuario) {
        usuario.setNombre(usuarioDTO.getNombre());
        usuario.setEdad(usuarioDTO.getEdad());
        usuario.setCorreo(usuarioDTO.getCorreo());
        usuario.setTelefono(usuarioDTO.getTelefono());
        usuario.setContraseA(usuarioDTO.getContraseA());
        final Role rol = usuarioDTO.getRol() == null ? null : roleRepository.findById(usuarioDTO.getRol())
                .orElseThrow(() -> new NotFoundException("rol not found"));
        usuario.setRol(rol);
        return usuario;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Inscripcione usuarioInscripcione = inscripcioneRepository.findFirstByUsuario(usuario);
        if (usuarioInscripcione != null) {
            referencedWarning.setKey("usuario.inscripcione.usuario.referenced");
            referencedWarning.addParam(usuarioInscripcione.getId());
            return referencedWarning;
        }
        return null;
    }

}
