package cursos.cursos_online.role.repos;

import cursos.cursos_online.role.domain.Role;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RoleRepository extends JpaRepository<Role, Integer> {
}
