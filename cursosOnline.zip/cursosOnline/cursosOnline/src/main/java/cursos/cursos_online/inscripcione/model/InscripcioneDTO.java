package cursos.cursos_online.inscripcione.model;

import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;


@Getter
@Setter
public class InscripcioneDTO {

    private Integer id;

    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private OffsetDateTime fechaInscripcion;

    private Integer usuario;

    private Integer curso;

}
